<?php
require_once "./MVC/Core/App.php";
require_once "./MVC/Core/Controller.php";
require_once "./MVC/Core/ConnectDB.php";
?>