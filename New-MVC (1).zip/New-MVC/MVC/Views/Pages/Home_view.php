<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style type="text/css">
        .aside {
            height: 580px;
            background-color: #f3f1f0;
            padding-top: 0px;
            border-right: solid 10px #211161;
            overflow: hidden;
            /* overflow-x: initial; */
            /* overflow-y: scroll; */
        }
        img{
            width: 100%;
            height: 100%;
        }
    </style>
</head>
<body>
    <img src="/New-MVC/Public/Image/ktx.jpg" >
</body>
</html>