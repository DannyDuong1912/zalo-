<?php
session_start();
require_once "./MVC/bridge.php";
$myApp = new App();
?>